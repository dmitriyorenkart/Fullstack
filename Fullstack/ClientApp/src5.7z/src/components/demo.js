
import React, { useContext, useState, useEffect }from 'react';
import Paper from '@material-ui/core/Paper';

import {
    Chart,
    BarSeries,
    Title,
    ArgumentAxis,
    ValueAxis,
} from '@devexpress/dx-react-chart-material-ui';
import { Animation } from '@devexpress/dx-react-chart';

function datediff(first, second) {
    // Take the difference between the dates and divide by milliseconds per day.
    // Round to nearest whole number to deal with DST.
    return Math.round((second - first) / (1000 * 60 * 60 * 24));
}

function Demo(props) {
    if (props.message.length == 0)
        return (null)
    debugger
    
 
          
    
        
       
      

        return (
            <Paper>
              
                <Chart
                    
                    dataSource={ data.message }
                >
                    <ArgumentAxis />
                    <ValueAxis max={7} />

                    <BarSeries
                        valueField="population"
                        argumentField="year"
                    />
                    <Title text="World population" />
                    <Animation />
                </Chart>
              
            </Paper>

        );
    
}


export default Demo;

