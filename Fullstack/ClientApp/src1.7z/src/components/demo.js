
import React from 'react';
import Paper from '@material-ui/core/Paper';
import {
    Chart,
    BarSeries,
    Title,
    ArgumentAxis,
    ValueAxis,
} from '@devexpress/dx-react-chart-material-ui';
import { Animation } from '@devexpress/dx-react-chart';

function datediff(first, second) {
    // Take the difference between the dates and divide by milliseconds per day.
    // Round to nearest whole number to deal with DST.
    return Math.round((second - first) / (1000 * 60 * 60 * 24));
}

function Demo (props) {
    
    
    if (props.message == undefined)
        return (null)

       let data1 = Array.from(new Array(props.message.length).keys()).map((e, x) => ({ 'year': x + 1, 'bar': datediff(new Date(props.message[x].date_Registration), new Date(props.message[x].date_LastActivity)) }));
    
        return (
            <Paper>
                <Chart
                    data={data1}
                >
                    <ArgumentAxis />
                    <ValueAxis max={7} />

                    <BarSeries
                        valueField="population"
                        argumentField="year"
                    />
                    <Title text="World population" />
                    <Animation />
                </Chart>

            </Paper>
           
        );
    
}

export default Demo;

